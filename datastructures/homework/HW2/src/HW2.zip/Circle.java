//package com.gradescope.hw2;
import bridges.base.Color;
import bridges.base.ColorGrid;

public class Circle extends Mark {
    public Circle(int radius, int xcenter, int ycenter, Color color) {

    }

    @Override
    public void draw(ColorGrid cg) {

    }
}
