//package com.gradescope.hw2;
import bridges.base.Color;
import bridges.base.ColorGrid;

public class DiagonalLine extends Mark {
    public DiagonalLine(int x0, int y0, int x1, int y1, Color color) {

    }

    @Override
    public void draw(ColorGrid cg) {

    }
}
