//package com.gradescope.hw2;
import bridges.base.Color;
import bridges.base.ColorGrid;

public class VerticalLine extends Mark {

    public VerticalLine(int start, int end, int x, Color c) {

    }

    @Override
    public void draw(ColorGrid cg) {

    }
}
