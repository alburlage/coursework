//package com.gradescope.hw2;
import bridges.base.Color;
import bridges.base.ColorGrid;

public class HorizontalLine extends Mark {

    public HorizontalLine(int start, int end, int y, Color c) {
    }

    @Override
    public void draw(ColorGrid cg) {
    }
}
